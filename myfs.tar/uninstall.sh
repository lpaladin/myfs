#!/bin/bash
umount ramdisk/
rmmod myfs
