#!/bin/bash
dmesg | grep myfs
