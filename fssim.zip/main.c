﻿#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

#include "structure.h"
#include "creat.h"
#include "access.h"
#include "ballfre.h"
#include "close.h"
#include "delete.h"
#include "dir.h"
#include "format.h"
#include "halt.h"
#include "iallfre.h"
#include "install.h"
#include "log.h"
#include "name.h"
#include "open.h"
#include "rdwt.h"

#include "igetput.h"

struct hinode hinodes[NHINO];

struct dir dir;
struct file sys_ofile[SYSOPENFILE];
struct filsys filsys;
struct pwd pwd[PWDNUM];
struct user user[USERNUM];
FILE *fd;
struct inode *cur_path_inode;
int user_id;

unsigned short usr_id;
char usr_p[12];
char sel;
char temp_dir[12];
int main()
{
	unsigned short ab_fd1;
	char *buf;
	int done = 1;

	printf("\n你希望格式化（重建文件系统）吗？请输入y或n。\n");
	if (getchar() == 'y')
	{
		printf("格式化中……\n");
		format();
		install();
		printf("\n==登录==\n请输入用户ID：");
		scanf("%u", &usr_id);
		printf("\n请输入密码：");
		scanf("%s", &usr_p);
		if (!login(usr_id, usr_p))
			return -1;
		while (done)
		{
			printf("\n请输入操作编号：\n");
			printf(" 【1】----列出目录内容\n 【2】----创建文件夹\n 【3】----改变当前目录\n 【4】----创建文件\n 【0】----注销\n");
			sel = getchar();
			sel = getchar();
			switch (sel)
			{
			case '1':   //显示目录内容
				_dir();
				break;
			case '2':  //创建目录
				printf("请输入新目录名：");
				scanf("%s", temp_dir);
				mkdir(temp_dir);
				break;
			case '3':  //改变当前目录
				printf("请输入目标目录名：");
				scanf("%s", temp_dir);
				chdir(temp_dir);
				break;
			case '4': //创建文件
				printf("请输入文件名：");
				scanf("%s", temp_dir);
				ab_fd1 = creat(2118, temp_dir, 01777);
				buf = (char *)malloc(BLOCKSIZ * 6 + 5);
				write(ab_fd1, buf, BLOCKSIZ * 6 + 5);
				close(0, ab_fd1);
				free(buf);
				break;
			case '0': //退出文件系统
				logout(usr_id);
				halt();
				done = 0;
			default:
				printf("抱歉，指定的命令不存在。\n");
				break;
			}
		}
	}
	else
		printf("用户取消操作。\n");
	return 0;
}



