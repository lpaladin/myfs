﻿#ifndef _STRUCTURE_H 
#define _STRUCTURE_H


#define MAX 32767
#define BLOCKSIZ 512
#define SYSOPENFILE 40
#define DIRNUM 128
#define DIRSIZ 14
#define PWDSIZ 12
#define PWDNUM 32
#define NOFILE 20
#define NADDR 10
#define NHINO 128
#define USERNUM 10
#define DINODESIZ 72

#define DINODEBLK 32
#define FILEBLK 512
#define NICFREE 50
#define NICINOD 50
#define DINODESTART 1024 
#define DATASTART (2+DINODEBLK)*BLOCKSIZ

#define DIEMPTY		00000
#define DIFILE		01000
#define DIDIR		02000

#define UDIREAD		00001
#define UDIWRITE	00002
#define UDIEXICUTE	00004
#define GDIREAD		00010
#define GDIWRITE	00020
#define GDIEXICUTE	00040
#define ODIREAD		00100
#define	ODIWRITE	00200
#define ODIEXICUTE	00400

#define READ	1
#define WRITE	2
#define	EXICUTE	3

#define DEFAULTMODE 00777

#define IUPDATE	00002
#define	SUPDATE	00001

#define FREAD	00001
#define FWRITE  00002
#define FAPPEND 00004

#define DISKFULL 65535

#define SEEK_SET 0


struct inode
{
	struct inode *i_forw;			// 指向前一个inode
	struct inode *i_back;			// 指向后一个inode
	char i_flag;					// 标志
	unsigned int i_ino;				// inode编号
	unsigned int i_count;			// inode引用次数
	unsigned int di_addr[NADDR];	// 数据块地址
	unsigned short di_number;		// 对应的目录数
	unsigned short di_mode;			// 权限位
	unsigned short di_uid;			// 所属用户编号
	unsigned short di_gid;			// 所属用户组编号
	unsigned short di_size;			// 大小
};

struct dinode // 对应inode里参数
{
	unsigned short di_number;
	unsigned short di_mode;
	unsigned short di_uid;
	unsigned short di_gid;
	unsigned long di_size;
	unsigned int di_addr[NADDR];
};
struct direct
{
	char d_name[DIRSIZ];
	unsigned int d_ino; // 对应inode编号
};

struct filsys
{
	unsigned short s_isize;			// 对应inode大小
	unsigned long s_fsize;			// 对应超级块大小

	unsigned int s_nfree;			// 指向空闲块的指针
	unsigned short s_pfree;
	unsigned int s_free[NICFREE];	// 空闲块数组

	unsigned int s_ninode;
	unsigned short s_pinode;
	unsigned int s_inode[NICINOD];
	unsigned int s_rinode;

	char s_fmod;					// 权限位
};

struct pwd
{
	unsigned short p_uid;
	unsigned short p_gid;
	char password[PWDSIZ];
};

struct dir
{
	struct direct direct[DIRNUM];
	int size;
};

struct hinode
{
	struct inode *i_forw;
};

struct file
{
	char f_flag;
	unsigned int f_count;
	struct inode *f_inode;
	unsigned long f_off;
};

struct user
{
	unsigned short u_default_mode;
	unsigned short u_uid;
	unsigned short u_gid;
	unsigned short u_ofile[NOFILE];
};

extern struct inode* aaa;
extern struct hinode hinodes[NHINO];
extern struct dir dir;
extern struct file sys_ofile[SYSOPENFILE];
extern struct filsys filsys;
extern struct pwd pwd[PWDNUM];
extern struct user user[USERNUM];
extern struct inode *cur_path_inode;
extern FILE *fd;
extern int user_id;

extern struct inode *iget(unsigned int dinodeid);//
extern void iput(struct inode *pinode);//
extern unsigned int balloc(); //
extern void bfree(unsigned int block_num);//
extern struct inode *ialloc();//
extern void ifree(unsigned dinodeid);//
extern int namei(char *name);//
extern short iname(char *name);//
extern unsigned int access(unsigned int user_id, struct inode *inode, unsigned short mode);//
extern void _dir();//
extern int mkdir(char *dirname);//
extern int chdir(char *dirname);//
extern unsigned short open(int user_id, char *filename, unsigned short openmode);//
extern int creat(unsigned int uid, char * filename, unsigned short mode);//
extern unsigned int read(int cfd, char *buf, unsigned int size);//
extern unsigned int write(int cfd, char *buf, unsigned int size);//
extern int login(unsigned short uid, char *passwd);//
extern int logout(unsigned short uid);//
extern void install();//
extern void format();//
extern void close(unsigned int user_id, unsigned short cfd);//
extern void halt();//





#endif
