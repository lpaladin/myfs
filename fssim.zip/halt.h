﻿#include <stdio.h>
#include "structure.h"

void halt()
{
	int i, j;

	for (i = 0; i < USERNUM; i++)
	{
		if (user[i].u_uid != 0)//是否还有用户
		{
			for (j = 0; j < NOFILE; j++)
			{
				if (user[i].u_ofile[j] != SYSOPENFILE + 1)
				{
					close(i, j);//user[i].u_ofile[j]);
					user[i].u_ofile[j] = SYSOPENFILE + 1;
				}
			}
		}
	}
	fseek(fd, BLOCKSIZ, SEEK_SET);
	fwrite(&filsys, 1, sizeof(struct filsys), fd);
	fclose(fd);
	printf("\n文件系统已经卸载。再见——\n");
	exit(0);
}
