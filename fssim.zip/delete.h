﻿#include <stdio.h>
#include "structure.h"

void deletefile(char *filename)
{
	unsigned int dinodeid;
	struct inode *inode;

	dinodeid = namei(filename);
	if (dinodeid != 0) //文件名是否为空
		inode = iget(dinodeid); //释放节点，删除文件
	inode->di_number--;
	iput(inode);
}

