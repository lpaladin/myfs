﻿#include <stdio.h>
#include "structure.h"

unsigned short open(int user_id, char *filename, unsigned short openmode)
{
	unsigned int dinodeid;
	struct inode *inode;
	int i, j;

	dinodeid = namei(filename);
	if (dinodeid != NULL) //系统是否存在与输入文件名相同的文件
	{
		printf("\n文件不存在！\n");
		return 0;
	}
	inode = iget(dinodeid);
	if (!access(user_id, inode, openmode))//用户是否具备访问文件的权限
	{
		printf("\n没有访问权限！\n");
		iput(inode);
		return 0;
	}

	for (i = 1; i < SYSOPENFILE; i++)
	if (sys_ofile[i].f_count == 0) break;
	if (i == SYSOPENFILE)
	{
		printf("\n系统打开的文件过多……\n");
		iput(inode);
		return 0;
	}
	sys_ofile[i].f_inode = inode;
	sys_ofile[i].f_flag = (char)openmode;
	sys_ofile[i].f_count = 1;
	if (openmode&FAPPEND)
		sys_ofile[i].f_off = inode->di_size;
	else
		sys_ofile[i].f_off = 0;

	for (j = 0; j < NOFILE; j++)
	if (user[user_id].u_ofile[j] == 0) break;
	if (j == NOFILE)
	{
		printf("\n用户打开的文件过多……\n");
		sys_ofile[i].f_count = 0;
		iput(inode);
		return 0;
	}
	user[user_id].u_ofile[j] = 1;

	if (openmode&FAPPEND)
	{
		for (i = 0; j < inode->di_size / BLOCKSIZ + 1; i++)
			bfree(inode->di_addr[i]);
		inode->di_size = 0;
	}
	return j;
}

