﻿#include <stdio.h>
#include "structure.h"

static unsigned int block_buf[BLOCKSIZ / sizeof(int)];
unsigned int balloc()  //分配数据块
{
	unsigned int free_block;

	int i, flag;

	if (filsys.s_nfree == 0) //先判断系统是否有空块
	{
		printf("\n磁盘已满！\n");
		return DISKFULL;
	}
	i = filsys.s_pfree;
	flag = (i == 0);


	if (flag)  //该BLOCK组全部用了，也就是超级块中没有空
		//开启新的块组，将其地址信息读入超级块
	{
		fseek(fd, DATASTART + BLOCKSIZ*(filsys.s_free[NICFREE - 1] + 1), SEEK_SET);
		//filsys.s_free[NICFREE-1]+1指向下一个block组的地址块
		fread(block_buf, 1, BLOCKSIZ, fd);
		for (i = 0; i < NICFREE; i++)
		{
			filsys.s_free[i] = block_buf[i];
		}//将待用block组的地址读入超级块
		filsys.s_pfree = NICFREE - 1;
		free_block = filsys.s_free[filsys.s_pfree];
	}
	else //超级块中有空块
	{
		free_block = filsys.s_free[filsys.s_pfree];
		filsys.s_pfree--;
	}
	filsys.s_nfree--;
	filsys.s_fmod = SUPDATE;

	return free_block;
}

void bfree(unsigned int block_num)  //回收数据块
{
	int i;

	if (filsys.s_pfree == NICFREE - 1)  //空闲块是否可以组成块组
		//表示回收的block已经可以组成一个block组了
	{  //将空闲的数据块组成一个块组，按序写入磁盘备用
		for (i = 0; i < NICFREE; i++)
		{
			block_buf[i] = filsys.s_free[NICFREE - 1 - i];
		}
		filsys.s_pfree = 0;  //超级块空闲指针清0

		fseek(fd, DATASTART + BLOCKSIZ*(filsys.s_free[0]), SEEK_SET);
		//filsys.s_free[0]为当前BLOCK组的地址块
		fwrite(block_buf, 1, BLOCKSIZ, fd);
	}
	else filsys.s_pfree++;//超级块空闲指针减1
	filsys.s_nfree++;
	filsys.s_fmod = SUPDATE;
}
